<template>
  <v-app>
    <router-view />
  </v-app>
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
body {
  font-family: "Roboto", sans-serif;
}
</style>
