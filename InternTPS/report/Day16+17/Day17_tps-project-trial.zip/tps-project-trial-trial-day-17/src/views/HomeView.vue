<template>
  <div>Home page</div>
</template>

<script>
export default {};
</script>

<style>
th,
td {
  border-right: 1px solid grey;
}
</style>
